import os
import pathlib
import shutil
import json

def get_forge_version_from_manifest(path):
    with open(path, encoding="UTF-8") as f:
        data = json.load(f)
        modloaders = (data["minecraft"]["modLoaders"])
        minecraft_version = data["minecraft"]["version"]
        for modloader in modloaders:
            if modloader["primary"] == True:
                return minecraft_version + "-" + modloader["id"][6:]


#print(get_forge_version_from_manifest("manifest.json"))

