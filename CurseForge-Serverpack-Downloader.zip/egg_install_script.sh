#!/bin/bash
# CurseForge Modpack Serverpack Installation Script
#
# Server Files: /mnt/server

# Install unzip, wget, python3, pip3 and java OpenJDK
apt update
apt -y install unzip
apy -y install wget
apt -y install python3
apt -y install python3-pip
apt -y install default-jre

# Go to server folder
cd /mnt/server

if [ -z "${MODPACK_VERSION}" ] || [ "${MODPACK_VERSION}" == "latest" ]; then
    MODPACK_VERSION="latest"
fi

wget -O CSD.zip https://github.com/astrooom/CurseForge-Serverpack-Downloader/blob/main/CurseForge-Serverpack-Downloader.zip?raw=true

unzip CSD.zip

pip3 install -r requirements.txt

python3 run.py ${MODPACK_ID} ${MODPACK_VERSION} 