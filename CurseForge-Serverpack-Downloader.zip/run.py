import os
from os.path import join
import subprocess
from time import sleep
import glob
from shutil import move
from get_modpack_info import get_server_modpack_url
from download_file import download
from unzip_modpack import unzip
import psutil
import pathlib
import platform
import sys

modpack_id = sys.argv[1]
modpack_version = sys.argv[2]

print("\n\nRecieved arguments to download modpack with ID", modpack_id, "with version", modpack_version)

#Checks OS to know which install file to execute (.bat or .sh)
operating_system = platform.system()

this_dir = os.path.dirname(os.path.realpath(__file__))

def up_one_directory(root, parent):
    for filename in os.listdir(join(root, parent)):
        move(join(root, parent, filename), join(root, filename))
    sleep(2)

def delete_directory(dir):
    os.rmdir(dir)
    print("\n\nDeleted directory in:", dir)

def kill(proc_pid):
    process = psutil.Process(proc_pid)
    for proc in process.children(recursive=True):
        proc.kill()
    process.kill()

#MODPACK PROJECT (Addon) IDs on CurseForge
SevTech_Ages_of_the_Sky = 403521
All_the_Mods_6 = 381671
SkyFactory_4 = 296062
Roguelike_Adventures_And_Dungeons = 289267
#The_Pixelmon_Modpack = 389615 #Technic Serverpack
MC_Eternal = 349129
Enigmatica_6 = 389471
Dungeons_Dragons_And_Space_Shuttles = 301717
Life_In_The_Village_2 = 402412
Zombie_Apocalypse = 445369
Better_Minecraft_Forge = 429793
Better_Minecraft_Fabric = 452013
#FTB_Revelation = 283861 #FTB Serverpack

modpack_info = get_server_modpack_url(modpack_id, modpack_version)
modpack_name = modpack_info[0]
modpack_urls = modpack_info[1]



#Grab URLs to modpack and download
if (modpack_urls["SpecifiedVersion"]):
    print("Downloading Specified Version of", modpack_name + "...")
    filename = download(modpack_urls["SpecifiedVersion"])

elif (modpack_urls["LatestReleaseServerpack"]):
    print("Downloading Latest Release of", modpack_name + "...")
    filename = download(modpack_urls["LatestReleaseServerpack"])

elif not modpack_urls["LatestReleaseServerpack"] and modpack_urls["LatestBetaServerpack"]:
    print("Downloading Latest Beta of", modpack_name + "...")
    filename = download(modpack_urls["LatestBetaServerpack"])

elif not modpack_urls["LatestReleaseServerpack"] and not modpack_urls["LatestBetaServerpack"] and modpack_urls["LatestAlphaServerpack"]:
    print("Downloading Latest Alpha of", modpack_name + "...")
    filename = download(modpack_urls["LatestAlphaServerpack"])

elif not modpack_urls["LatestReleaseServerpack"] and not modpack_urls["LatestBetaServerpack"] and not modpack_urls["LatestAlphaServerpack"] and modpack_urls["LatestReleaseNonServerpack"]:
    print("Downloading Latest Non-Serverpack of", modpack_name + "...")
    filename = download(modpack_urls["LatestReleaseNonServerpack"])


#Unzip downloaded modpack zip
folder_name = unzip(filename, modpack_name)

modpack_folder = os.listdir(this_dir + "/" + folder_name)

#Count number of files
file_count = 0
for filename in modpack_folder: 
    file_count += 1

# Go to lone subdirectory if zip is constructed wrong
if file_count == 1:
    for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "*"):
        if name:
            if os.path.isdir(name):
                print("\n\nFound nested folder, moving contents to parent directory")
                #print(this_dir + "/" + folder_name + "/" + folder_name)
                subfolder_path = pathlib.PurePath(name)
                subfolder_name = subfolder_path.name
                up_one_directory(this_dir + "/" + folder_name, this_dir + "/" + folder_name + "/" + subfolder_name)
                sleep(2)
                delete_directory(this_dir + "/" + folder_name + "/" + subfolder_name)
                # modpack_folder = os.listdir(this_dir + "/" + folder_name + "/" + folder_name)
                # this_dir = (this_dir + "/" + folder_name + "/" + folder_name)

#Check if forge installer exists in serverpack dir. If does, run it.
forge_installer = False
for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "*installer.jar"):
    if name:
        forge_installer = True
        print("\n\nChanging Directory for forge installer")
        os.chdir(f"{this_dir}/{folder_name}")
        print("\n\nRunning Forge Installer. This may take a minute or two...")
        os.system(f"java -jar {name} --installServer")
        print("\n\nFinished running forge installer")
        os.remove(name)
        print("\n\nRemoved forge installer")
        try:
            os.remove(name + ".log")
            print("\n\nRemoved forge installer log")
        except:
            pass

#Check if serverstarter installer exists in serverpack dir. If does, run it.
serverstarter_installer = False
for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "*.yaml"):
    if name:
        serverstarter_installer = True
        if operating_system == "Windows":
            file_ext = "*.bat"
            print("\n\nDetected Windows Operating System")
        if operating_system == "Linux":
            file_ext = "*.sh"
            print("\n\nDetected Linux Operating System")
        if operating_system == "Mac OS":
            file_ext = "*.sh"
            print("\n\nDetected Mac OS Operating System")
        for file in glob.glob(this_dir + "/" + folder_name + "/" + f"{file_ext}"):
            print("\n\nChanging Directory for serverstarter installer")
            os.chdir(f"{this_dir}/{folder_name}")
            print("\n\nRunning Serverstarter Installer. This may take a minute or two...")
            p = subprocess.Popen(f"{file}", stdout=subprocess.PIPE, shell=True)
            for line in p.stdout:
                if b"The server installed successfully" in line:
                    print("\n\nGot Installer Finished Message")  # Terminates script when script has succesfully installed all mods and forge files etc. and stops it from running the server
                    break
            kill(p.pid)
            print("\n\nTerminated serverstarter installer...")
            print("\n\nDeleting Serverstarter")
            os.remove(file)

# manifest_installer = False
# if not forge_installer and not serverstarter_installer:
#     for name in glob.glob(this_dir + "/" + folder_name + "/" + "manifest.json"):
#         if name:
#             manifest_installer = True
#             print("\n\nRunning manifest installer...")
#             os.system(f"python {this_dir}/curse_downloader.py --manifest {this_dir}/{folder_name}/manifest.json --nogui")
            
            



#Garbage files cleanup
print("\n\nRunning garbage cleanup...")
for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "*installer.jar"):
    if name:
        print("Removing", name)
        os.remove(name)
for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "*.log"):
    if name:
        os.remove(name)
for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "*download.zip"):
    if name:
        print("Removing", name)
        os.remove(name)
for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "*.yaml"):
    if name:
        print("Removing", name)
        os.remove(name)
for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "serverstarter*"):
    if name:
        print("Removing", name)
        os.remove(name)
for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "*.sh"):
    if name:
        print("Removing", name)
        os.remove(name)
for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "*.bat"):
    if name:
        print("Removing", name)
        os.remove(name)

for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "forge*.jar"):
    if name:
        print("\n\nRenaming", name, "to server.jar")
        os.chdir(f"{this_dir}/{folder_name}")
        os.rename(name, "server.jar")

has_properties = False
for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/") + "server.properties"):
    if name:
        has_properties = True
        print("\n\nserver.properties file already found. Skipping download.")
if not has_properties:
    print("\n\nNo server.properties file was found. Downloading...")
    download('https://raw.githubusercontent.com/parkervcp/eggs/master/minecraft/java/server.properties')


for name in glob.glob(glob.escape(this_dir + "/" + folder_name + "/")):
    subfolder_path = pathlib.PurePath(name)
    subfolder_name = subfolder_path.name
    up_one_directory(this_dir, this_dir + "/" + folder_name)
    os.chdir(this_dir)
    sleep(3)
    delete_directory(this_dir + "/" + folder_name)
    print("\n\nMoved all modpack files to root directory")

print("\n\n\n\nFinished installing modpack", modpack_name + "! :)")



