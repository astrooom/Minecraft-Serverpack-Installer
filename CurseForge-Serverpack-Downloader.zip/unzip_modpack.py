import os
import pathlib
import shutil


dir_path = os.path.dirname(os.path.realpath(__file__))

def unzip(zip_name, modpack_name):

    extract_dir = dir_path + "\\" + modpack_name.replace(":", "_").replace(" ", "_").replace(",", "")
    my_zip = dir_path + f"\{zip_name}"

    
    shutil.unpack_archive(my_zip, extract_dir)
    print("\n\nExtraction Done, deleting zip")

    os.remove(my_zip)

    path = pathlib.PurePath(extract_dir)

    return path.name


#check_modpack_files("SevTech: Ages of the Sky")